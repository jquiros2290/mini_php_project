<?php

if(isset($_POST['all_clients'])){
	getAllClients(); 
}

//Returns all records in the clients table
function getAllClients(){

	$conn = new mysqli("localhost","root","root","Monkedia");
	
	if ($conn->connect_error){
	  die("Connection failed: " . $conn->connect_error);
  	}

  	$sql="SELECT * FROM clients";

	$result = $conn->query($sql);

	if ($result->num_rows > 0) {
		$html = "";
	    while($row = $result->fetch_assoc()) {
	        $html .= "<tr> <td>" . $row["ID"] . "</td> <td>" . $row["Name"] . "</td> </tr>";
		    }
		} else {
		    echo "0 results";
		}

		echo $html;

	$conn->close();
}




?>