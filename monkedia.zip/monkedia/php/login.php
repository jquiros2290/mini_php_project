<?php 
	
	//Calling Login Method using post request data
	if(isset($_POST['username']) && isset($_POST['password'])){
		login($_POST['username'], $_POST['password']); 
	}

	//Returning whether a user is logged in or not
	if(isset($_GET['session'])){
		session_start();
		echo $_SESSION['logged_in'];
	}

	//Will destroy session when logging out
	if(isset($_POST['session'])){
		session();
	}


	function login($username, $password){

		$options = [
		    'cost' => 12,
		];

		$hash_password = password_hash($password, PASSWORD_BCRYPT, $options);

		$conn = new mysqli("localhost","root","root","Monkedia");
		
		if ($conn->connect_error){
		  die("Connection failed: " . $conn->connect_error);
	  	}

	  	$sql="SELECT * FROM users WHERE Username = '$username'";

		$result = $conn->query($sql);
		
		if ($result->num_rows > 0) {
			while($row = $result->fetch_assoc()) {
				if(password_verify($password, $row['Password'])){
					session(true); //Setting $_SESSION['logged_in'] = 'yes';
					echo true;
				}else{
					echo false;
				}
			}
		} else {
		    $sql = "INSERT INTO users (Username, Password) VALUES ('$username', '$hash_password')";

			mysqli_query($conn, $sql);

			session(true); //Setting $_SESSION['logged_in'] = 'yes';

			echo true;
		}
			
		$conn->close();

	}

	function session($logged_in=false){
		session_start();

		if($logged_in == true){
			$_SESSION['logged_in'] = 'yes';
		}else{
			session_destroy();
			echo 'Sucessfully logged out.';
		}

	}



?>