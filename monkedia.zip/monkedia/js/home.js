//Returns all records in the clients table
function getData(clients = 'clients'){
	var posting = $.post('php/script.php', {
		all_clients: clients
	});

	posting.done(function(data){
		$('#content').html(data);
	});

	posting.fail(function(data){
	});
}

//Returns whether a user is logged in or not
function getSession(){
	var get_session = $.get('php/login.php', {
		session: ''
	});

	get_session.done(function(data){
		if(data != 'yes'){
			window.location.assign("http://localhost:8888/monkedia");
		}
	});

	get_session.fail(function(data){
	});

}

//Destroys the user session
function logout(session = 'destroy'){
	var session = $.post('php/login.php', {
		session: session

	});

	session.done(function(data){
		window.location.assign("http://localhost:8888/monkedia");
	});

	session.fail(function(data){
	});
}

 
$(document).ready(function(){
	getSession();
	getData();

	$( "#logout" ).click(function() {
		logout();
	});
});