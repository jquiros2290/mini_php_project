//Attempt to register/log user in 
function login(username, password){

	var posting = $.post('php/login.php', {
		username: username,
		password: password
	});

	posting.done(function(data){
		if(data == true){
			window.location.assign("http://localhost:8888/monkedia/home.html");	
		}else{
			$('#errors').html('Sorry, the username you have selected is either already taken or the password you have entered is not correct.');
		}
	});

	posting.fail(function(data){
	});
}

//Checking if user is logged in
function getSession(){
	var get_session = $.get('php/login.php', {
		session: ''

	});

	get_session.done(function(data){
		if(data == 'yes'){
			window.location.assign("http://localhost:8888/monkedia/home.html");
		}
	});

	get_session.fail(function(data){
	});

}
 
$(document).ready(function(){

	getSession();

	$("#login").on('submit', function (e) {
        e.preventDefault();
        var data = {
            username: $("#username").val(),
            password: $("#password").val()
        };
        login(data['username'], data['password']);

    });
});